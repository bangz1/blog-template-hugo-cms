import React from 'react';

export default function AffiliateLink({ href, children }) {
  const handleClick = () => {
    if (window.gtag) {
      window.gtag('event', 'affiliate_click', {
        event_category: 'Affiliate',
        event_label: href,
        transport_type: 'beacon',
      });
    }
  };

  return (
    <a href={href} target="_blank" rel="noopener noreferrer" onClick={handleClick}>
      {children}
    </a>
  );
}