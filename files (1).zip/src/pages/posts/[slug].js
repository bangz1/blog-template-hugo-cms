import fs from 'fs';
import path from 'path';
import matter from 'gray-matter';
import Head from 'next/head';
import ReactMarkdown from 'react-markdown';
import AffiliateLink from '../../components/AffiliateLink';

export async function getStaticPaths() {
  const postsDir = path.join(process.cwd(), 'content/posts');
  const files = fs.readdirSync(postsDir).filter(f => f.endsWith('.md'));
  const paths = files.map(file => ({
    params: { slug: file.replace('.md', '') }
  }));
  return { paths, fallback: false };
}

export async function getStaticProps({ params }) {
  const filePath = path.join(process.cwd(), 'content/posts', `${params.slug}.md`);
  const fileContents = fs.readFileSync(filePath, 'utf8');
  const { data, content } = matter(fileContents);
  return { props: { meta: data, content } };
}

export default function Post({ meta, content }) {
  return (
    <>
      <Head>
        <title>{meta.title}</title>
        <meta name="description" content={meta.description} />
        <meta name="keywords" content={meta.keywords} />
        {/* Analytics tracking script */}
        <script async src="https://www.googletagmanager.com/gtag/js?id=YOUR_GA_ID"></script>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              window.dataLayer = window.dataLayer || [];
              function gtag(){dataLayer.push(arguments);}
              gtag('js', new Date());
              gtag('config', 'YOUR_GA_ID');
            `,
          }}
        />
      </Head>
      <article>
        <h1>{meta.title}</h1>
        <ReactMarkdown
          components={{
            a: ({node, ...props}) => {
              if (props.href.includes('amzn.to')) {
                return <AffiliateLink {...props} />;
              }
              return <a {...props} />;
            }
          }}
        >
          {content}
        </ReactMarkdown>
      </article>
    </>
  );
}