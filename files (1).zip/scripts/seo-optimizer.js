const fs = require("fs");
const path = require("path");

function addSEOMeta(postPath, keywords) {
  let content = fs.readFileSync(postPath, "utf-8");
  const meta = `
---
title: ${keywords.title}
description: ${keywords.description}
keywords: ${keywords.keywords.join(", ")}
---
  `;
  content = meta + content;
  fs.writeFileSync(postPath, content);
}

module.exports = addSEOMeta;