const { OpenAI } = require("openai");
const fs = require("fs");
const path = require("path");

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

async function generatePost(keyword) {
  const prompt = `Write a detailed blog post about "${keyword}" for a smart home security affiliate site. Include product recommendations, pros and cons, and embed affiliate links using [AffiliateLink:ProductName].`;

  const response = await openai.chat.completions.create({
    model: "gpt-4",
    messages: [{ role: "user", content: prompt }],
    max_tokens: 2000,
  });

  const postContent = response.choices[0].message.content;
  const filePath = path.join(__dirname, "../content/posts/", `${keyword.replace(/ /g, "-")}.md`);
  fs.writeFileSync(filePath, postContent);
}

module.exports = generatePost;