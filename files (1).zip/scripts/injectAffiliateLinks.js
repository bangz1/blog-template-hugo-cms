const fs = require('fs');
const path = require('path');

const affiliateLinks = {
  'Ring Alarm': 'https://amzn.to/YOUR_RING_LINK',
  'Nest Secure': 'https://amzn.to/YOUR_NEST_LINK',
  'Smart Doorbell': 'https://amzn.to/YOUR_DOORBELL_LINK',
  'Wireless Motion Sensor': 'https://amzn.to/YOUR_SENSOR_LINK',
};

const postsDir = path.join(__dirname, '../content/posts/');
const posts = fs.readdirSync(postsDir);

posts.forEach(postFile => {
  let content = fs.readFileSync(path.join(postsDir, postFile), 'utf8');
  Object.entries(affiliateLinks).forEach(([product, url]) => {
    const regex = new RegExp(`\\[AffiliateLink:${product}\\]`, 'g');
    content = content.replace(regex, `[${product}](${url})`);
  });
  fs.writeFileSync(path.join(postsDir, postFile), content);
  console.log(`Injected links into: ${postFile}`);
});