const fs = require("fs");
const path = require("path");

const affiliateLinks = {
  "Ring Alarm": "https://amzn.to/xyz123",
  "Nest Secure": "https://amzn.to/abc789",
};

function replaceAffiliateLinks(postPath) {
  let content = fs.readFileSync(postPath, "utf-8");
  Object.keys(affiliateLinks).forEach(product => {
    const regex = new RegExp(`\\[AffiliateLink:${product}\\]`, "g");
    content = content.replace(regex, `[${product}](${affiliateLinks[product]})`);
  });
  fs.writeFileSync(postPath, content);
}

module.exports = replaceAffiliateLinks;