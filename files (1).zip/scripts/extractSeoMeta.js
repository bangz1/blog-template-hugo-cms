const fs = require('fs');
const path = require('path');

const postsDir = path.join(__dirname, '../content/posts/');
const posts = fs.readdirSync(postsDir);

posts.forEach(postFile => {
  const content = fs.readFileSync(path.join(postsDir, postFile), 'utf8');
  const match = content.match(/^---\n([\s\S]+?)\n---\n/);
  if (!match) return;

  const frontmatter = match[1];
  const meta = {};
  frontmatter.split('\n').forEach(line => {
    const [key, ...vals] = line.split(':');
    meta[key.trim()] = vals.join(':').trim();
  });

  const jsonFile = postFile.replace('.md', '.json');
  fs.writeFileSync(path.join(postsDir, jsonFile), JSON.stringify(meta, null, 2));
  console.log(`Extracted SEO meta for: ${postFile}`);
});