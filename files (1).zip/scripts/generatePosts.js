require('dotenv').config({ path: '.env.local' });
const { OpenAI } = require('openai');
const fs = require('fs');
const path = require('path');

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const keywords = [
  'Best Smart Home Security Cameras 2025',
  'Ring Alarm vs Nest Secure: Which Is Better?',
  'How to Install Smart Doorbells',
  'Top Wireless Motion Sensors for Home Security',
  'DIY vs Professional Smart Home Security Systems',
];

async function generatePost(keyword) {
  const prompt = `
Write a detailed, SEO-optimized blog post about "${keyword}" for a smart home security affiliate website.
Include product recommendations, pros and cons, and mark places for affiliate links as [AffiliateLink:ProductName].
Provide meta title, meta description, and 5 SEO keywords at the top as YAML frontmatter.
`;

  const response = await openai.chat.completions.create({
    model: 'gpt-4',
    messages: [{ role: 'user', content: prompt }],
    max_tokens: 1800,
  });

  const content = response.choices[0].message.content;
  const fileName = `${keyword.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.md`;
  const filePath = path.join(__dirname, '../content/posts/', fileName);

  fs.writeFileSync(filePath, content);
  console.log(`Generated: ${fileName}`);
}

(async () => {
  for (const keyword of keywords) {
    await generatePost(keyword);
  }
})();